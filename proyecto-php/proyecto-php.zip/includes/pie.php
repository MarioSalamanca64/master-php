
			<div class="clearfix"></div>
		</div> <!-- fin contenedor -->

		<!-- PIE DE PÁGINA -->
		<div class="clearfix"></div>
		<footer id="pie">
			<p>Proyecto de Mario salamanca &copy; 2021</p>
		</footer>
		
	</body>
</html>
